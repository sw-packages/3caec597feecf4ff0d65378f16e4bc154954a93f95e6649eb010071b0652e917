#ifdef __cplusplus
extern "C" {
#endif

void *csa_memcpy(void *dest, const void *src, size_t n);

#ifdef __cplusplus
} /* end extern "C" */
#endif
